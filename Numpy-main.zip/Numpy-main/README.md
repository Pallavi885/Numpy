# Numpy
This repository consist of Numpy Basics.
